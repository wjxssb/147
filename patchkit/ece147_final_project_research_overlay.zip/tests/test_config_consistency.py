from pathlib import Path

from omegaconf import OmegaConf

ROOT = Path(__file__).resolve().parents[1]


def test_ablation_presets_are_consistent():
    model = OmegaConf.load(ROOT / "config/model/research_bigru.yaml")
    transform = OmegaConf.load(ROOT / "config/transforms/research_ablation.yaml")
    for experiment_name in (
        "full32", "left16", "right16", "balanced16", "balanced8",
        "fs1000", "fs500", "fs250",
    ):
        experiment = OmegaConf.load(ROOT / f"config/experiment/{experiment_name}.yaml")
        cfg = OmegaConf.merge(model, transform, experiment)
        OmegaConf.resolve(cfg)
        assert len(cfg.sensor.fields) == cfg.module.num_bands, experiment_name
        assert len(cfg.sensor.indices) == cfg.module.channels_per_band, experiment_name
        assert cfg.sensor.n_fft // 2 + 1 == cfg.module.freq_bins, experiment_name
        assert cfg.sensor.n_fft / cfg.sensor.sample_rate == 0.032, experiment_name
        assert cfg.sensor.hop_length / cfg.sensor.sample_rate == 0.008, experiment_name
        assert cfg.module.mlp_offsets == [0], experiment_name
