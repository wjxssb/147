from pathlib import Path
import sys

import torch

sys.path.insert(0, str(Path(__file__).parents[1]))
from emg2qwerty.research_models import CNNRNNEncoder, minimum_ctc_frames
from emg2qwerty.research_transforms import SelectElectrodeChannels, SafeTemporalAlignmentJitter
sys.path.insert(0, str(Path(__file__).parents[1] / "scripts"))
from error_analysis import analyze, hand


def test_electrodes_are_physically_sliced():
    x = torch.arange(2 * 5 * 16).reshape(5, 2, 16)
    out = SelectElectrodeChannels([0, 4, 8, 12])(x)
    assert out.shape == (5, 2, 4)
    assert out[0, 0, :].tolist() == [0, 4, 8, 12]


def test_ctc_repeated_labels():
    targets = torch.tensor([[2, 1], [2, 3], [3, 5]])
    assert minimum_ctc_frames(targets, [3, 3]).tolist() == [4, 3]


def test_one_band_jitter_does_not_crash():
    x = torch.randn(100, 1, 16)
    assert torch.equal(SafeTemporalAlignmentJitter(120)(x), x)


def test_rnn_uses_packed_lengths():
    torch.set_num_threads(2)
    enc = CNNRNNEncoder(num_features=12, hidden_dim=10, num_layers=2)
    y = enc(torch.randn(30, 2, 12), lengths=torch.tensor([22, 30]))
    assert y.shape == (30, 2, 12)
    assert (y[22:, 0] == 0).all()


def test_reference_side_diagnostics_not_fake_hand_cer():
    assert hand("b") == "left"
    data = analyze("abc", "axc!")
    assert data["global_cer"] == 2 / 3
    assert data["substitutions"] == 1 and data["insertions"] == 1
    assert "left_cer" not in data and "right_cer" not in data
