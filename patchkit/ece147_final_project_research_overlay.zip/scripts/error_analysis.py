"""Deterministic character-alignment diagnostics, NOT an independent hand CER.

Usage: python scripts/error_analysis.py 'shetypes' 'sjetyes'
Insertions have no reference character; report them separately.
Multiple optimal Levenshtein traces may produce different hand attribution.
"""
from __future__ import annotations

import argparse
import json
from collections import Counter

LEFT = set("qwertasdfgzxcvb")  # Conventional QWERTY touch-typing side; B is left
RIGHT = set("yuiophjklnm")


def hand(char: str | None) -> str:
    c = (char or "").lower()
    if c in LEFT:
        return "left"
    if c in RIGHT:
        return "right"
    return "other"


def align(reference: str, hypothesis: str):
    """Return edit trace (operation, ref_char|None, hyp_char|None).

    Tie policy: diagonal (match/sub), deletion, insertion. This is one of
    potentially multiple equally minimal Levenshtein alignments.
    """
    a, b = reference, hypothesis
    m, n = len(a), len(b)
    dp = [[0] * (n + 1) for _ in range(m + 1)]
    for i in range(m + 1):
        dp[i][0] = i
    for j in range(n + 1):
        dp[0][j] = j
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            dp[i][j] = min(
                dp[i - 1][j - 1] + (a[i - 1] != b[j - 1]),
                dp[i - 1][j] + 1,
                dp[i][j - 1] + 1,
            )
    ops = []
    i, j = m, n
    while i or j:
        if i and j and dp[i][j] == dp[i - 1][j - 1] + (a[i - 1] != b[j - 1]):
            ops.append(("M" if a[i - 1] == b[j - 1] else "S", a[i - 1], b[j - 1]))
            i -= 1
            j -= 1
        elif i and dp[i][j] == dp[i - 1][j] + 1:
            ops.append(("D", a[i - 1], None))
            i -= 1
        else:
            ops.append(("I", None, b[j - 1]))
            j -= 1
    ops.reverse()
    return ops


def analyze(reference: str, hypothesis: str) -> dict:
    ops = align(reference, hypothesis)
    per_ref = {k: Counter() for k in ("left", "right", "other")}
    insertion_by_predicted = Counter()
    global_errors = Counter()
    for op, ref_c, hyp_c in ops:
        if op == "I":
            insertion_by_predicted[hand(hyp_c)] += 1
        else:
            c = per_ref[hand(ref_c)]
            c["reference_chars"] += 1
            if op == "S":
                c["substitutions"] += 1
            elif op == "D":
                c["deletions"] += 1
        if op != "M":
            global_errors[op] += 1
    n = len(reference)
    results = {}
    for name, counts in per_ref.items():
        d = counts["reference_chars"]
        results[name] = {
            "reference_chars": d,
            "substitutions": counts["substitutions"],
            "deletions": counts["deletions"],
            "sub_del_rate": ((counts["substitutions"] + counts["deletions"]) / d if d else None),
        }
    return {
        "reference_chars": n,
        "global_cer": ((sum(global_errors.values()) / n) if n else None),
        "substitutions": global_errors["S"],
        "deletions": global_errors["D"],
        "insertions": global_errors["I"],
        "reference_anchored": results,
        "insertions_by_predicted_side": dict(insertion_by_predicted),
        "ambiguity_note": "Side-level edit counts depend on deterministic tie-breaking; they are diagnostics, not standard hand CER.",
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("reference")
    parser.add_argument("hypothesis")
    args = parser.parse_args()
    print(json.dumps(analyze(args.reference, args.hypothesis), indent=2, ensure_ascii=False))
