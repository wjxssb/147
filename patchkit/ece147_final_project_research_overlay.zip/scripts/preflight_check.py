"""CPU-only smoke test: synthetic signals, no dataset, no Hydra requirements.
Run from repository root: python scripts/preflight_check.py
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

import torch
import torchaudio

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from emg2qwerty.research_models import CNNRNNEncoder, minimum_ctc_frames, tds_output_lengths
from emg2qwerty.research_transforms import SelectElectrodeChannels, ResampleEMG


def main():
    torch.manual_seed(42)
    torch.set_num_threads(min(torch.get_num_threads(), 4))
    # Check physical channel selection: input (T, B, C).
    xs = torch.arange(96 * 2 * 16).reshape(96, 2, 16).float()
    assert SelectElectrodeChannels([0, 2, 4, 6, 8, 10, 12, 14])(xs).shape == (96, 2, 8)
    assert torch.equal(SelectElectrodeChannels([0, 4, 8, 12])(xs)[..., 1], xs[..., 4])

    # Check full 4-s window: 32-ms STFT and 8-ms hop maintain 497 frames.
    # Actual STFT center=False; resampler includes anti-alias filtering.
    shape_rows = []
    waveform = torch.randn(8000, 2, 16)
    for sr, fft, hop, bins in [
        (2000, 64, 16, 33), (1000, 32, 8, 17),
        (500, 16, 4, 9), (250, 8, 2, 5),
    ]:
        x = ResampleEMG(2000, sr)(waveform)
        spec = torchaudio.transforms.Spectrogram(
            n_fft=fft, hop_length=hop, normalized=True, center=False
        )(x.movedim(0, -1)).movedim(-1, 0)
        assert spec.shape == (497, 2, 16, bins), tuple(spec.shape)
        assert abs(sr / fft - 31.25) < 1e-7
        shape_rows.append({"rate": sr, "raw_T": len(x), "feature_T": len(spec), "bins": bins})

    # Training input usually includes 1800+200 raw context samples: 622 frames.
    padded_frames = []
    for sr, fft, hop, _ in [(2000, 64, 16, 33), (1000, 32, 8, 17), (500, 16, 4, 9), (250, 8, 2, 5)]:
        padded = ResampleEMG(2000, sr)(torch.randn(10_000, 2, 16))
        frame_count = (len(padded) - fft) // hop + 1
        padded_frames.append(frame_count)
    assert padded_frames == [622] * 4

    # A clipped boundary window need not align exactly across sample rates.
    # For 9900 raw samples, a 250-Hz sinc-resampled path can gain a frame.
    # Fail-fast implementations must NOT assume exact output equality.
    import math
    irregular = 9900
    base_frames = (irregular - 64) // 16 + 1
    resampled_count = math.ceil(irregular * 250 / 2000)
    coarse_frames = (resampled_count - 8) // 2 + 1
    assert coarse_frames != base_frames

    # Check minimum CTC sequence time: 'book' has one consecutive 'oo' repeat.
    labels = torch.tensor([[1, 1], [2, 2], [2, 3], [3, 4]], dtype=torch.long)
    mins = minimum_ctc_frames(labels, [4, 4])
    assert mins.tolist() == [5, 4], mins.tolist()
    assert tds_output_lengths(torch.tensor([497, 497]), 32, 4).tolist() == [373, 373]

    # Packed BiGRU with different feature lengths and a valid backward pass.
    net = CNNRNNEncoder(16, hidden_dim=8, num_layers=2, dropout=0.1)
    inp = torch.randn(25, 2, 16, requires_grad=True)
    out = net(inp, torch.tensor([25, 17]))
    assert out.shape == inp.shape
    assert torch.count_nonzero(out[17:, 1, :]) == 0
    out.square().sum().backward()
    assert torch.isfinite(inp.grad).all()

    print(json.dumps({"status": "PASS (synthetic CPU smoke tests)", "stft": shape_rows, "padded_window_frame_counts": padded_frames, "irregular_boundary_frame_counts": [base_frames, coarse_frames], "ctc_min": mins.tolist()}, indent=2))
    print("NOTE: Real training, data splits, decoder, and CUDA memory remain UNVERIFIED.")


if __name__ == "__main__":
    main()
