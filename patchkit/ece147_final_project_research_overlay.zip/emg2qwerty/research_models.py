"""Research-only temporal encoders and explicit CTC alignment checks.

Overlay beside (not instead of) the original emg2qwerty/modules.py.
"""
from __future__ import annotations

from collections.abc import Sequence

import torch
from torch import nn
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence


class CNNRNNEncoder(nn.Module):
    """Time-preserving Conv1d + packed bidirectional GRU/LSTM.

    Input/output: (time, batch, features). `lengths` are feature-frame counts,
    NOT raw sEMG sample counts. Packing removes padded frames from the RNN,
    but the common upstream SpectrogramNorm is not padding-aware.
    """

    def __init__(
        self,
        num_features: int,
        hidden_dim: int = 256,
        num_layers: int = 2,
        dropout: float = 0.2,
        cell: str = "gru",
    ) -> None:
        super().__init__()
        if num_features <= 0 or hidden_dim <= 0 or num_layers <= 0:
            raise ValueError("Feature width, hidden width and layer count must be positive")
        if cell not in ("gru", "lstm"):
            raise ValueError("cell must be 'gru' or 'lstm'")
        self.num_features = num_features
        self.conv = nn.Conv1d(num_features, num_features, kernel_size=3, padding=1)
        self.activation = nn.GELU()
        self.conv_norm = nn.LayerNorm(num_features)
        rnn_type = nn.GRU if cell == "gru" else nn.LSTM
        self.rnn = rnn_type(
            input_size=num_features,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            bidirectional=True,
            dropout=dropout if num_layers > 1 else 0.0,
        )
        self.projection = nn.Linear(2 * hidden_dim, num_features)
        self.output_norm = nn.LayerNorm(num_features)
        self.dropout = nn.Dropout(dropout)

    def forward(self, inputs: torch.Tensor, lengths: torch.Tensor | None = None) -> torch.Tensor:
        if inputs.ndim != 3 or inputs.shape[-1] != self.num_features:
            raise ValueError(f"Expected (T, N, {self.num_features}), got {tuple(inputs.shape)}")
        t, n, _ = inputs.shape
        residual = self.conv_norm(self.activation(self.conv(inputs.permute(1, 2, 0)).permute(2, 0, 1)))
        if lengths is None:
            encoded, _ = self.rnn(residual)
            valid = None
        else:
            lengths_cpu = torch.as_tensor(lengths, dtype=torch.long).cpu()
            if len(lengths_cpu) != n or (lengths_cpu <= 0).any() or (lengths_cpu > t).any():
                raise ValueError("Every feature-frame length must lie in [1, T]")
            packed = pack_padded_sequence(residual, lengths_cpu, enforce_sorted=False)
            encoded, _ = self.rnn(packed)
            encoded, _ = pad_packed_sequence(encoded, total_length=t)
            valid = torch.arange(t, device=inputs.device)[:, None] < lengths_cpu.to(inputs.device)[None, :]
        out = self.output_norm(residual + self.dropout(self.projection(encoded)))
        if valid is not None:
            out = out.masked_fill(~valid[..., None], 0.0)
        return out


def minimum_ctc_frames(targets: torch.Tensor, target_lengths: Sequence[int] | torch.Tensor) -> torch.Tensor:
    """For padded (U, N) target ids, require U plus adjacent repeated labels.

    A CTC path of exactly U frames is insufficient for repeated adjacent labels.
    """
    if targets.ndim != 2:
        raise ValueError("targets must be time-major shape (U, N)")
    lengths = torch.as_tensor(target_lengths, dtype=torch.long, device=targets.device)
    if lengths.numel() != targets.shape[1] or (lengths < 0).any() or (lengths > targets.shape[0]).any():
        raise ValueError("target_lengths incompatible with padded target array")
    if targets.shape[0] <= 1:
        return lengths
    repeated = targets[1:, :] == targets[:-1, :]
    time_idx = torch.arange(1, targets.shape[0], device=targets.device)[:, None]
    repeated = repeated & (time_idx < lengths[None, :])
    return lengths + repeated.sum(dim=0)


def tds_output_lengths(lengths: torch.Tensor, kernel_width: int, num_blocks: int) -> torch.Tensor:
    """Exact length for the upstream valid temporal convolutions (stride=1)."""
    if kernel_width < 1 or num_blocks < 1:
        raise ValueError("kernel_width and num_blocks must be positive")
    return torch.as_tensor(lengths) - num_blocks * (kernel_width - 1)
