"""Stage-scoped datasets and explicit disjoint-session validation.

Avoid opening test HDF5 files during routine train/validation runs.
"""
from __future__ import annotations

from pathlib import Path

from torch.utils.data import ConcatDataset

from emg2qwerty.data import WindowedEMGDataset
from emg2qwerty.lightning import WindowedEMGDataModule


class ResearchEMGDataModule(WindowedEMGDataModule):
    def setup(self, stage: str | None = None) -> None:
        splits = {
            "train": {Path(p).stem for p in self.train_sessions},
            "val": {Path(p).stem for p in self.val_sessions},
            "test": {Path(p).stem for p in self.test_sessions},
        }
        for a, b in (("train", "val"), ("train", "test"), ("val", "test")):
            overlap = splits[a] & splits[b]
            if overlap:
                raise ValueError(f"Leaking sessions between {a} and {b}: {sorted(overlap)}")
        if stage in (None, "fit", "validate"):
            self.train_dataset = ConcatDataset([
                WindowedEMGDataset(
                    p, transform=self.train_transform,
                    window_length=self.window_length, padding=self.padding, jitter=True
                ) for p in self.train_sessions
            ])
            self.val_dataset = ConcatDataset([
                WindowedEMGDataset(
                    p, transform=self.val_transform,
                    window_length=self.window_length, padding=self.padding, jitter=False
                ) for p in self.val_sessions
            ])
        if stage in (None, "test", "predict"):
            self.test_dataset = ConcatDataset([
                WindowedEMGDataset(
                    p, transform=self.test_transform,
                    window_length=None, padding=(0, 0), jitter=False
                ) for p in self.test_sessions
            ])
