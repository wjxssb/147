"""Isolated Lightning module: preserves upstream TDSConvCTCModule unchanged.

Designed for Calvin-Pang/emg2qwerty at commit
376923bcb4892d8cddae0ca7cd3d472ae11d93aa.
"""
from __future__ import annotations

from collections.abc import Sequence
from typing import Any

import pytorch_lightning as pl
import torch
from hydra.utils import instantiate
from omegaconf import DictConfig
from torch import nn
from torchmetrics import MetricCollection

from emg2qwerty import utils
from emg2qwerty.charset import charset
from emg2qwerty.data import LabelData
from emg2qwerty.metrics import CharacterErrorRates
from emg2qwerty.modules import (
    MultiBandRotationInvariantMLP,
    SpectrogramNorm,
    TDSConvEncoder,
)
from emg2qwerty.research_models import CNNRNNEncoder, minimum_ctc_frames, tds_output_lengths


class ResearchCTCModule(pl.LightningModule):
    def __init__(
        self,
        num_bands: int,
        channels_per_band: int,
        freq_bins: int,
        mlp_features: Sequence[int],
        encoder_type: str,
        optimizer: DictConfig,
        lr_scheduler: DictConfig,
        decoder: DictConfig,
        hidden_dim: int = 256,
        num_layers: int = 2,
        dropout: float = 0.2,
        block_channels: Sequence[int] = (24, 24, 24, 24),
        kernel_width: int = 32,
        mlp_offsets: Sequence[int] = (-1, 0, 1),
        invalid_ctc_policy: str = "raise",  # or 'zero' with logged dropped samples
    ) -> None:
        super().__init__()
        if not (num_bands in (1, 2) and channels_per_band > 0 and freq_bins > 0 and mlp_features):
            raise ValueError("Invalid sensor/model dimension configuration")
        if invalid_ctc_policy not in ("raise", "zero"):
            raise ValueError("invalid_ctc_policy must be 'raise' or 'zero'")
        if encoder_type not in ("tds", "gru", "lstm"):
            raise ValueError("encoder_type must be tds, gru, or lstm")
        self.save_hyperparameters()
        self.num_bands = num_bands
        self.channels_per_band = channels_per_band
        self.freq_bins = freq_bins
        self.encoder_type = encoder_type
        self.invalid_ctc_policy = invalid_ctc_policy
        num_features = num_bands * mlp_features[-1]
        self.feature_extractor = nn.Sequential(
            SpectrogramNorm(channels=num_bands * channels_per_band),
            MultiBandRotationInvariantMLP(
                in_features=channels_per_band * freq_bins,
                mlp_features=mlp_features,
                num_bands=num_bands,
                offsets=mlp_offsets,
            ),
            nn.Flatten(start_dim=2),
        )
        self.encoder = (
            TDSConvEncoder(
                num_features=num_features,
                block_channels=block_channels,
                kernel_width=kernel_width,
            )
            if encoder_type == "tds"
            else CNNRNNEncoder(
                num_features=num_features,
                hidden_dim=hidden_dim,
                num_layers=num_layers,
                dropout=dropout,
                cell=encoder_type,
            )
        )
        self.classifier = nn.Sequential(
            nn.Linear(num_features, charset().num_classes), nn.LogSoftmax(dim=-1)
        )
        self.ctc_loss = nn.CTCLoss(
            blank=charset().null_class,
            zero_infinity=(invalid_ctc_policy == "zero"),
        )
        self.decoder = instantiate(decoder)
        metric_collection = MetricCollection([CharacterErrorRates()])
        self.metrics = nn.ModuleDict(
            {f"{phase}_metrics": metric_collection.clone(prefix=f"{phase}/")
             for phase in ("train", "val", "test")}
        )

    def feature_lengths(self, lengths: torch.Tensor) -> torch.Tensor:
        if self.encoder_type == "tds":
            return tds_output_lengths(
                lengths, self.hparams.kernel_width, len(self.hparams.block_channels)
            )
        return lengths

    def forward(
        self, inputs: torch.Tensor, input_lengths: torch.Tensor | None = None
    ) -> torch.Tensor:
        if inputs.ndim != 5 or tuple(inputs.shape[2:]) != (
            self.num_bands, self.channels_per_band, self.freq_bins
        ):
            raise ValueError(
                f"Expected inputs (T,N,{self.num_bands},{self.channels_per_band},{self.freq_bins}); "
                f"got {tuple(inputs.shape)}"
            )
        x = self.feature_extractor(inputs)
        if self.encoder_type == "tds":
            x = self.encoder(x)
        else:
            x = self.encoder(x, lengths=input_lengths)
        return self.classifier(x)

    def _step(self, phase: str, batch: dict[str, torch.Tensor], *args: Any, **kwargs: Any) -> torch.Tensor:
        inputs = batch["inputs"]
        targets = batch["targets"]
        input_lengths = batch["input_lengths"]
        target_lengths = batch["target_lengths"]
        n = int(input_lengths.numel())
        emission_lengths = self.feature_lengths(input_lengths)
        needed = minimum_ctc_frames(targets, target_lengths)
        invalid = (emission_lengths.to(needed.device) < needed) | (emission_lengths.to(needed.device) <= 0)
        invalid_count = int(invalid.sum().item())
        self.log(
            f"{phase}/ctc_invalid_count", float(invalid_count),
            on_step=False, on_epoch=True, reduce_fx="sum", sync_dist=True,
        )
        self.log(
            f"{phase}/ctc_invalid_fraction", float(invalid_count) / max(n, 1),
            batch_size=n, on_step=False, on_epoch=True, sync_dist=True,
        )
        if invalid_count and self.invalid_ctc_policy == "raise":
            bad_indices = torch.nonzero(invalid).flatten().tolist()
            raise ValueError(
                f"CTC cannot align {invalid_count}/{n} examples at indices {bad_indices}. "
                f"emission_lengths={emission_lengths.tolist()}, minimum_required={needed.tolist()}"
            )

        emissions = self.forward(inputs, input_lengths=input_lengths)
        if int(emissions.shape[0]) != int(self.feature_lengths(
            torch.as_tensor([inputs.shape[0]])
        )[0]):
            raise RuntimeError("Temporal encoder output length does not match declared length rule")
        if not torch.isfinite(emissions).all():
            raise FloatingPointError("Model produced NaN/Inf log probabilities")
        loss = self.ctc_loss(
            log_probs=emissions,
            targets=targets.transpose(0, 1),
            input_lengths=emission_lengths,
            target_lengths=target_lengths,
        )
        if not torch.isfinite(loss):
            raise FloatingPointError("CTC loss is nonfinite: inspect logits and alignment lengths")
        predictions = self.decoder.decode_batch(
            emissions=emissions.detach().cpu().numpy(),
            emission_lengths=emission_lengths.detach().cpu().numpy(),
        )
        metrics = self.metrics[f"{phase}_metrics"]
        true_targets = targets.detach().cpu().numpy()
        true_lengths = target_lengths.detach().cpu().numpy()
        for i in range(n):
            truth = LabelData.from_labels(true_targets[:true_lengths[i], i])
            metrics.update(prediction=predictions[i], target=truth)
        self.log(f"{phase}/loss", loss, batch_size=n, sync_dist=True)
        return loss

    def _epoch_end(self, phase: str) -> None:
        metrics = self.metrics[f"{phase}_metrics"]
        self.log_dict(metrics.compute(), sync_dist=True)
        metrics.reset()

    def training_step(self, *args: Any, **kwargs: Any) -> torch.Tensor:
        return self._step("train", *args, **kwargs)

    def validation_step(self, *args: Any, **kwargs: Any) -> torch.Tensor:
        return self._step("val", *args, **kwargs)

    def test_step(self, *args: Any, **kwargs: Any) -> torch.Tensor:
        return self._step("test", *args, **kwargs)

    def on_train_epoch_end(self) -> None:
        self._epoch_end("train")

    def on_validation_epoch_end(self) -> None:
        self._epoch_end("val")

    def on_test_epoch_end(self) -> None:
        self._epoch_end("test")

    def configure_optimizers(self) -> dict[str, Any]:
        return utils.instantiate_optimizer_and_scheduler(
            self.parameters(), self.hparams.optimizer, self.hparams.lr_scheduler
        )
