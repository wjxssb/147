"""Research entrypoint: evaluate validation only until final_test=true.

Run from repository root:
  python -m emg2qwerty.research_train model=research_bigru \
      transforms=research_ablation +experiment=full32 trainer.max_epochs=40

The original emg2qwerty/train.py tests after every train; repeated test peeking
can bias decisions. Here we gate the final test behind `+final_test=true`.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

import hydra
import pytorch_lightning as pl
from hydra.utils import get_original_cwd, instantiate
from omegaconf import DictConfig, ListConfig, OmegaConf

from emg2qwerty import transforms, utils

log = logging.getLogger(__name__)


@hydra.main(version_base=None, config_path="../config", config_name="base")
def main(config: DictConfig) -> None:
    pl.seed_everything(int(config.seed), workers=True)
    original_root = Path(get_original_cwd())

    def paths(sessions: ListConfig) -> list[Path]:
        root = Path(config.dataset.root)
        return [root / f"{item['session']}.hdf5" for item in sessions]

    def build_transform(steps) -> transforms.Compose:
        return transforms.Compose([instantiate(step) for step in steps])

    module = instantiate(
        config.module,
        optimizer=config.optimizer,
        lr_scheduler=config.lr_scheduler,
        decoder=config.decoder,
        _recursive_=False,
    )
    if config.checkpoint is not None:
        module = module.load_from_checkpoint(
            config.checkpoint, optimizer=config.optimizer,
            lr_scheduler=config.lr_scheduler, decoder=config.decoder,
        )
    datamodule = instantiate(
        config.datamodule,
        batch_size=config.batch_size,
        num_workers=config.num_workers,
        train_sessions=paths(config.dataset.train),
        val_sessions=paths(config.dataset.val),
        test_sessions=paths(config.dataset.test),
        train_transform=build_transform(config.transforms.train),
        val_transform=build_transform(config.transforms.val),
        test_transform=build_transform(config.transforms.test),
        _convert_="object",
    )
    callbacks = [instantiate(cfg) for cfg in config.get("callbacks", [])]
    trainer = pl.Trainer(**config.trainer, callbacks=callbacks)
    best_path = None
    if bool(config.train):
        ckpt_dir = Path.cwd() / "checkpoints"
        resume_from = utils.get_last_checkpoint(ckpt_dir)
        trainer.fit(module, datamodule, ckpt_path=resume_from)
        best_path = trainer.checkpoint_callback.best_model_path
        if best_path:
            module = module.load_from_checkpoint(best_path)
    else:
        if config.checkpoint is None:
            raise ValueError("train=false requires checkpoint=/path/to/model.ckpt")
        best_path = str(config.checkpoint)

    val_metrics = trainer.validate(module, datamodule, verbose=False)
    output: dict[str, Any] = {
        "seed": int(config.seed),
        "best_checkpoint": best_path,
        "val_metrics": val_metrics,
        "parameters": sum(p.numel() for p in module.parameters()),
        "config": OmegaConf.to_container(config, resolve=True),
        "test_evaluated": False,
    }
    if bool(config.get("final_test", False)):
        log.warning("FINAL TEST enabled: do not use test scores to select hyperparameters")
        output["test_metrics"] = trainer.test(module, datamodule, verbose=False)
        output["test_evaluated"] = True
    outpath = Path.cwd() / "research_results.json"
    outpath.write_text(json.dumps(output, indent=2, default=str), encoding="utf8")
    print(f"Wrote {outpath}; test_evaluated={output['test_evaluated']}")


if __name__ == "__main__":
    OmegaConf.register_new_resolver("cpus_per_task", utils.cpus_per_task)
    main()
