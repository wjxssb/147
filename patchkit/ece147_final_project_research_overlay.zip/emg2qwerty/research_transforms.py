"""Sensor-level transforms for controlled sEMG ablations."""
from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass

import numpy as np
import torch
import torchaudio.functional as AF


@dataclass
class SelectElectrodeChannels:
    indices: Sequence[int]
    channel_dim: int = -1

    def __call__(self, tensor: torch.Tensor) -> torch.Tensor:
        dim = self.channel_dim % tensor.ndim
        indices = list(map(int, self.indices))
        if tensor.ndim < 2 or not indices or len(set(indices)) != len(indices):
            raise ValueError("Expected a nonempty set of distinct physical electrode indices")
        if min(indices) < 0 or max(indices) >= tensor.shape[dim]:
            raise IndexError("Electrode index outside recorded band")
        return torch.index_select(tensor, dim, torch.as_tensor(indices, device=tensor.device))


@dataclass
class ResampleEMG:
    orig_freq: int = 2000
    new_freq: int = 1000
    lowpass_filter_width: int = 12
    rolloff: float = 0.9475937167399596

    def __call__(self, tensor: torch.Tensor) -> torch.Tensor:
        if tensor.ndim != 3:
            raise ValueError("Expected (raw_time, bands, channels)")
        if self.orig_freq <= 0 or self.new_freq <= 0:
            raise ValueError("Sample rates must be positive")
        if self.new_freq > self.orig_freq:
            raise ValueError("Use this transform for equal-rate or downsampling only")
        if self.new_freq == self.orig_freq:
            return tensor
        t, b, c = tensor.shape
        x = tensor.reshape(t, b * c).T.contiguous().float()
        y = AF.resample(
            x, orig_freq=self.orig_freq, new_freq=self.new_freq,
            lowpass_filter_width=self.lowpass_filter_width,
            rolloff=self.rolloff,
            resampling_method="sinc_interp_hann",
        )
        return y.T.contiguous().reshape(-1, b, c)


@dataclass
class SafeTemporalAlignmentJitter:
    """Optional; disabled for *all* channel-ablation conditions to avoid confounding."""
    max_offset: int = 120
    stack_dim: int = 1

    def __call__(self, tensor: torch.Tensor) -> torch.Tensor:
        bands = tensor.shape[self.stack_dim]
        if bands == 1 or self.max_offset == 0:
            return tensor
        if bands != 2:
            raise ValueError("Temporal alignment jitter assumes one or two bands")
        left, right = tensor.unbind(self.stack_dim)
        offset = int(np.random.randint(-self.max_offset, self.max_offset + 1))
        if offset > 0:
            left, right = left[offset:], right[:-offset]
        elif offset < 0:
            left, right = left[:offset], right[-offset:]
        return torch.stack((left, right), dim=self.stack_dim)
